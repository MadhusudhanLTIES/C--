/**
 * @File   client.c
 * @Brief  Test application for Arrayent server interface.
 *
 * Copyright (c) 2012 Arrayent Inc.  Company confidential.
 * Please contact sales@arrayent.com to get permission to use in your
 * application.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <semaphore.h>
#include <time.h>
#include <unistd.h>
#include <string.h>

#include "aic.h"

static int token;
static sem_t callbackSem;

int main(int argc, char** argv)
{
 
  char* said = argv[1];
  char* password = argv[2];
  char* aeskey = argv[3];
  char* id = argv[4];
  

  int arg;
  char buf[4096]; 
 

  // Init the semaphores and queues;
  if(sem_init(&callbackSem, 0, 1) < 0) {
    printf("<%s> Unable to establish connection, closing daemon.\n",said);
    fflush(stdout);
    exit(1);
  }


  // Initialize connection
  printf("<%s> Starting connection to Arrayent daemon...\n",said);
  unsigned tries = 5;
  while(ArrayentInitWithId(said) < 0) {
    printf("<%s> Connection to Arrayent daemon failed.  Retrying...\n",said);
    fflush(stdout);
    usleep(100000);
    tries--;
    if(tries <= 0) {
      printf("<%s> Unable to establish connection, closing daemon.\n",said);
      fflush(stdout);
      exit(1);
    }
  } 

  //Configure Connection
  memcpy(buf, aeskey, 32);
  if(ArrayentSetProperty("sys-aeskey", buf) < 0) {
    printf("<%s> Could not connect to server.\n",said);
    fflush(stdout);
    exit(1);
  }
  //sprintf(buf, "%d", atoi(id));
  sprintf(buf, "%d", 11);
  printf("------------------->   |%s|\n",buf);
  if(ArrayentSetProperty("sys-productid", buf) < 0) {
    printf("<%s> Could not connect to server.\n",said);
    fflush(stdout);
    exit(1);
  }
  sprintf(buf, "%s", said);
  sprintf(&buf[48], "%s", password);
  if(ArrayentSetCredentials(buf, &buf[48]) < 0) {
    printf("<%s> could not connect to server.\n",said);
    fflush(stdout);
    exit(1);
  }

  //////////////////////////////////////////////
  /* sprintf(buf,"%s","q1.applianceconnect.net"); */
  /* if(ArrayentSetProperty("sys-lbname1", buf) < 0) { */
  /*   printf("<%s> Could not connect to server.\n",said); */
  /*   fflush(stdout); */
  /*   exit(1); */
  /* } */

  /* sprintf(buf,"%s","q2.applianceconnect.net"); */
  /* if(ArrayentSetProperty("sys-lbname2", buf) < 0) { */
  /*   printf("<%s> Could not connect to server.\n",said); */
  /*   fflush(stdout); */
  /*   exit(1); */
  /* } */

  /* sprintf(buf,"%s","q3.applianceconnect.net"); */
  /* if(ArrayentSetProperty("sys-lbname3", buf) < 0) { */
  /*   printf("<%s> Could not connect to server.\n",said); */
  /*   fflush(stdout); */
  /*   exit(1); */
  /* } */
  
  


  //////////////////////////////////////////////



  // Get network status from server

  printf("Waiting for network status from Arrayent daemon...\n");
  if(ArrayentNetStatus(&arg) < 0) {
    printf("Connection to Arrayent daemon failed");
    //bailout(i);
  }
  printf("   status: 0x%04x\n", arg);
  sleep(1);
 
  usleep(5000000);

  int hello = ArrayentHello();
  if(hello) {
    printf("\nConnection to Arrayent daemon failed");
    exit(1);
  } else {
    printf("success hello: %d\n",hello);
  }


  printf("<%s> Connection to Arrayent daemon sucessful.\n",said);
  fflush(stdout);

  char input[1024];  //used to collect data from outside
  char buffer[1024]; //used to send data to cloud
  
  char networkData[1024]; //used to get data from the cloud
  int length;  //holds the length of data from the cloud
  int timeout =0;
  int tmp = -1;

  /////////////////////////////////////////////////////////////////////////

  
  //Per suggestion by Albert
  sprintf(buf, "%d", 1);
  if(ArrayentSetProperty("sys-productid", buf) < 0) {
    printf("<%s> Could not set GetDeviceInformation property\n",said);
    fflush(stdout);
    exit(1);
  }
  else {
    printf("sys-productid set to 1\n");
    fflush(stdout);
  }
 


  //RE Albert: This is where I am expecting to receive data for Arrayent.
  while(1) {
    
    if(tmp-- == 0) {
      break;
    }
    length = 0;
    int result = ArrayentRecvData(networkData,&length,timeout);
    printf("Length of packet: %d\n",length);
    int index = 0;
    buffer[0] = 0;
    for(index = 0; index < length; index++) {
      char temporary[8]; 
      sprintf(temporary,"%2x",networkData[index]);
      strcat(buffer,temporary);
    }
    printf("Data from the cloud (%d): %s\n",result,buffer);
    fflush(stdout);

    //}
  
  //RE Albert: After this point in time I am listening for hexidecimal input
  //I translate this to binary and send it to the cloud
  

  //////////////////////////////////////////////////////////////////////////

  //char previous[100];
  
  //usleep(100000);
  //while(1) {
    
    fflush(stdout);
    usleep(5000000);
    /**
    sprintf(input,"%s","0000ED0006E72100000102");

      //scanf("%s",input);
    
    //break loop when sent exit command
    if(input[0] == 'e' && input[1] == 'x' && input[2] == 'i' && input[3] == 't') {
      break;
    }


    

    //find size of packet, abort if packet size is not divisible by 2
    int size;
    for(size = 0; size < 255; size++) {
      if(input[size] == 0) {
	break;
      }
    }
    if(size % 2 != 0) {
      continue;
    }

    printf("<%s> Sending packet %s\n",said,input);
    
    //printf("SAID: %s Password: %s AESKEY: %s ID: %s Message: %s\n",said,password,aeskey,id,message);


    //convert hex string to binary character buffer
    int kkk;
    for(kkk = 0; kkk < size; kkk += 2) {
      char tmp[2];
      tmp[0] = input[kkk];
      tmp[1] = input[kkk+1];
      int number = (int)strtol(tmp, NULL, 16);
      buffer[kkk/2] = (char)number;
    }
  
    
    unsigned tries = 1000;
    while(1) {
      if(tries <= 0) {
	printf("<%s> Packet failed to be delivered.\n",said);
	break;
      }
        if(ArrayentSendData(buffer, kkk/2, 10000) < 0) {
	tries--;
	//usleep(100);
      }
      else {
	printf("<%s> Packet sent sucessfully\n",said);
	fflush(stdout);
	break;
      }

    }
    
    */
    
    
    
  } 
  
}
